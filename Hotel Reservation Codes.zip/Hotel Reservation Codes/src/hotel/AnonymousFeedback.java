package hotel;

import java.util.Scanner;

public class AnonymousFeedback {

    private final int rating;
    private final String comment;

    public AnonymousFeedback(int rating, String comment) {
        this.rating = rating;
        this.comment = comment;
    }

    public int getRating() {
        return rating;
    }

    public String getComment() {
        return comment;
    }

}
