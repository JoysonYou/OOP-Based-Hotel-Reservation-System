package functions.activitiesdb;

import hotel.Activity;
import hotel.Reservation;
import tool.SafeIntegerInput;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import users.Customer;

public class ManageActivities {

    private static List<Activity> activities = InitializeActivities.initializeActivities();

    public static void createNewActivity(Scanner scanner) {
        System.out.println("Creating a New Activity");

        System.out.print("Enter activity name: ");
        scanner.nextLine(); // Clear the buffer
        String name = scanner.nextLine();

        LocalDate date = inputActivityDate(scanner, "Enter the date for the activity (YYYY-MM-DD): ");

        System.out.print("Enter the capacity for the activity: ");
        int capacity = SafeIntegerInput.safeIntegerInput(scanner);

        Activity newActivity = new Activity(name, date, capacity);
        activities.add(newActivity);

        System.out.println("New activity created successfully: " + name);
    }

    private static LocalDate inputActivityDate(Scanner scanner, String prompt) {
        LocalDate date = null;
        while (date == null) {
            System.out.print(prompt);
            String dateString = scanner.next();
            try {
                date = LocalDate.parse(dateString);
                if (date.isBefore(LocalDate.now())) {
                    System.out.println("Activity date cannot be in the past. Please try again.");
                    date = null;
                }
            } catch (DateTimeParseException e) {
                System.out.println("Invalid date format. Please enter the date in YYYY-MM-DD format.");
            }
        }
        return date;
    }

    public static void bookActivityForCustomer(Scanner scanner, Customer customer) {
        System.out.println("Available Activities:");
        for (int i = 0; i < activities.size(); i++) {
            Activity activity = activities.get(i);
            System.out.println((i + 1) + ". " + activity.getName() + " on " + activity.getDate());
        }

        System.out.print("Choose an activity to book: ");
        int choice = SafeIntegerInput.safeIntegerInput(scanner) - 1;
        Activity selectedActivity = activities.get(choice);

        if (customerCanJoinActivity(customer, selectedActivity)) {
            if (selectedActivity.addParticipant(customer)) {
                System.out.println("Successfully booked " + selectedActivity.getName());
            } else {
                System.out.println("Sorry, this activity is fully booked.");
            }
        } else {
            System.out.println("This activity is not available during your stay.");
        }
    }

    private static boolean customerCanJoinActivity(Customer customer, Activity activity) {
        for (Reservation reservation : customer.getReservations()) {
            if (!activity.getDate().isBefore(reservation.getCheckInDate())
                    && !activity.getDate().isAfter(reservation.getCheckOutDate())) {
                return true;
            }
        }
        return false;
    }

    public static List<Activity> getEnrolledActivities(Customer customer) {
        List<Activity> enrolledActivities = new ArrayList<>();
        for (Activity activity : activities) { // Assuming 'activities' is your list of all activities
            if (activity.getParticipants().contains(customer)) {
                enrolledActivities.add(activity);
            }
        }
        return enrolledActivities;
    }
}
