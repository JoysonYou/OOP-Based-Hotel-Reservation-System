package functions.activitiesdb;

import hotel.Activity;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class InitializeActivities {

    public static List<Activity> initializeActivities() {//String name, LocalDate date, int capacity
        List<Activity> activities = new ArrayList<>(Arrays.asList(
                new Activity("\"Space\" Art Exhibition", LocalDate.of(2023, 12, 30), 2)
        ));
        return activities;
    }

}
