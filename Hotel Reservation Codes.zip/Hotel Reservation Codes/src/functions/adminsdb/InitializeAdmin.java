package functions.adminsdb;

import users.Admin;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class InitializeAdmin {

    // A method to initialize admin data
    public static List<Admin> initializeAdmins() {//id, password, name, contactDetails
        List<Admin> admins = new ArrayList<>(Arrays.asList(
                new Admin(100000, "123456", "Marry Ann", "18654616515"),
                new Admin(100001, "123456", "Eddy Cue", "13815838898")
        ));
        return admins;
    }

}
