package functions.adminsdb;

import java.util.List;
import java.util.Scanner;
import tool.SafeIntegerInput;
import users.Admin;

public class ManageAdmin {

    private static List<Admin> admins = InitializeAdmin.initializeAdmins(); // = ... initialize or retrieve existing admins

    public static List<Admin> getAdmins() {
        return admins;
    }

    public static void addAdmin(Scanner scanner) {
        System.out.println("Adding a New Admin");

        System.out.print("Enter admin's name: ");
        scanner.nextLine(); // Clear the buffer
        String name = scanner.nextLine();

        System.out.print("Enter admin's password: ");
        String password = scanner.nextLine();

        System.out.print("Enter admin's contact number: ");
        String contactDetails = String.valueOf(SafeIntegerInput.safeIntegerInput(scanner));

        // Generate a unique ID for the admin, for example, using the size of the admins list
        int adminId = admins.size() + 100000;

        Admin newAdmin = new Admin(adminId, password, name, contactDetails);
        admins.add(newAdmin);
//        for (Admin admin :admins){
//            System.out.println(admin.toString());}
        System.out.println("New admin added successfully. Admin ID: " + adminId);
    }

    public static Admin findAdminById(int adminId) {
        for (Admin admin : admins) {
            if (admin.getId() == adminId) {
                return admin;
            }
        }
        return null;
    }

}
