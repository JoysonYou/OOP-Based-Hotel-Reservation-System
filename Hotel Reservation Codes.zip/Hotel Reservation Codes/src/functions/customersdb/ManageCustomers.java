package functions.customersdb;

import functions.adminlogin.AssignCustomerToRandomAdmin;
import java.util.Scanner;
import users.Customer;
import java.util.List;
import functions.customerlogin.ManageSelectedCustomerReservations;
import tool.SafeIntegerInput;
import users.VIPCustomer;

public class ManageCustomers {

    private static List<Customer> customers = InitializeCustomers.initializeCustomers();

    public static List<Customer> getCustomers() {
        return customers;
    }

    public static void registerNewCustomer(Scanner scanner) {
        System.out.println("Registering a New Customer");

        System.out.print("Enter customer's name: ");
        scanner.nextLine(); // Clear the buffer if coming from nextInt or similar
        String name = scanner.nextLine();

        System.out.print("Enter customer's password: ");
        String password = scanner.nextLine();

        System.out.print("Enter customer's contact number: ");
        String contactDetails = String.valueOf(SafeIntegerInput.safeIntegerInput(scanner));

        // Generate a unique ID for the customer, for example, using the size of the customers list
        int customerId = customers.size() + 200000;
        Customer newCustomer = new Customer(customerId, password, name, contactDetails);
        customers.add(newCustomer);

        System.out.println("New customer registered successfully. Customer ID: " + customerId);
        AssignCustomerToRandomAdmin.assignCustomerToRandomAdmin(newCustomer);
    }

    public static void manageCustomerReservations(Scanner scanner) {
        System.out.println("Manage Customer Reservations");

        if (customers.isEmpty()) {
            System.out.println("There are no registered customers.");
            return;
        }

        System.out.println("List of Customers:");
        for (int i = 0; i < customers.size(); i++) {
            Customer customer = customers.get(i);
            System.out.println((i + 1) + ". " + customer.getName() + " (ID: " + customer.getId() + ")");
        }

        System.out.print("Select a customer by ID: ");
        int customerId = SafeIntegerInput.safeIntegerInput(scanner);
        Customer selectedCustomer = findCustomerById(customerId);

        if (selectedCustomer == null) {
            System.out.println("Customer not found.");
            return;
        }

        ManageSelectedCustomerReservations.manageSelectedCustomerReservations(scanner, selectedCustomer);
    }

    public static Customer findCustomerById(int customerId) {
        for (Customer customer : customers) {
            if (customer.getId() == customerId) {
                return customer;
            }
        }
        return null;
    }

    public static int findCustomerIndex(List<Customer> customersList, Customer customer) {
        for (int i = 0; i < customersList.size(); i++) {
            if (customersList.get(i).getId() == customer.getId()) {
                return i;
            }
        }
        return -1;
    }

    // Replace a Customer with VIPCustomer in the list
    public static void replaceCustomerWithVIP(int customerId, VIPCustomer vipCustomer) {
        for (int i = 0; i < customers.size(); i++) {
            if (customers.get(i).getId() == customerId) {
                customers.get(i).setIsVIP(true);
//                customers.set(i, vipCustomer); // Replaces the customer with VIPCustomer
                break;
            }
        }
    }

    // Method to upgrade a Customer to VIPCustomer
    public static void upgradeCustomerToVIP(int customerId) {
        Customer customer = findCustomerById(customerId);
        if (customer != null && (customer.isIsVIP() == false)) {
            customer.setIsVIP(true);
            VIPCustomer vipCustomer = new VIPCustomer(customer.getId(), customer.getPassword(), customer.getName(), customer.getContactDetails());
            replaceCustomerWithVIP(customerId, vipCustomer);
            System.out.println("You are VIP now.");
        }
    }

}
