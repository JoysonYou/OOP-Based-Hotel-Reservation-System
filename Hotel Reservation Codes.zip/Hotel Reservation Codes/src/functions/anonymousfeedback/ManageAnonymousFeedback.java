package functions.anonymousfeedback;

import hotel.AnonymousFeedback;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ManageAnonymousFeedback {

    private static List<AnonymousFeedback> anonymousFeedbacks = new ArrayList<>();

    public static void collectAnonymousFeedback(Scanner scanner) {
        System.out.println("Please rate your experience (1-5): ");
        int rating = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.println("Please leave your feedback:");
        String comment = scanner.nextLine();

        AnonymousFeedback feedback = new AnonymousFeedback(rating, comment);
        anonymousFeedbacks.add(feedback);
        System.out.println("Customer Feedback:");
        System.out.println("Rating: " + feedback.getRating() + "/5");
        System.out.println("Comment: " + feedback.getComment());
        System.out.println("---");
        System.out.println("Thank you for your feedback!");
    }
}
