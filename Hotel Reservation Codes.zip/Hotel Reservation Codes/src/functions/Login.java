package functions;

import java.util.Scanner;
import functions.adminlogin.AdminMenu;
import functions.customerlogin.CustomerMenu;
import functions.adminsdb.ManageAdmin;
import functions.anonymousfeedback.ManageAnonymousFeedback;
import tool.SafeIntegerInput;

public class Login {
    
    public static void run() {
        Scanner scanner = new Scanner(System.in);
        
        boolean exit = false;
        System.out.println("Welcome to the Hotel Reservation System");
        
        while (!exit) {
            System.out.println("\nPlease choose an option:");
            System.out.println("1. Login as Admin");
            System.out.println("2. Login as Customer");
            System.out.println("3. Add New Admin");
            System.out.println("4. Customer Anonymous Feedback");
            System.out.println("5. Exit");
            System.out.println("");
            System.out.print("Enter your choice: ");
            int choice = SafeIntegerInput.safeIntegerInput(scanner);
            
            switch (choice) {
                case 1:
                    AdminMenu.handleAdminLogin(scanner);
                    break;
                case 2:
                    CustomerMenu.handleCustomerLogin(scanner);
                    break;
                case 3:
                    ManageAdmin.addAdmin(scanner);
                    break;
                case 4:
                    ManageAnonymousFeedback.collectAnonymousFeedback(scanner);
                    break;
                case 5:
                    exit = true;
                    System.out.println("Thank you for using the Hotel Reservation System.");
                    break;
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        }
        
        scanner.close();
    }
    
}
