package functions.roomsdb;

import java.util.ArrayList;
import java.util.List;
import rooms.Room;
import rooms.RoomType;

public class ManageAvailableRooms {

    private static List<Room> rooms = InitializeRooms.initializeRooms();

    public static List<Room> getAvailableRooms() {
        List<Room> availableRooms = new ArrayList<>();
        for (Room room : rooms) {
            if (room.isAvailable()) {
                availableRooms.add(room);
            }
        }
        return availableRooms;
    }

    public static Room findAvailableRoom(RoomType type) {//封装到roomreposity里面
        for (Room room : rooms) {
            if (room.getType() == type && room.isAvailable()) {
                return room;
            }
        }
        return null;
    }

}
