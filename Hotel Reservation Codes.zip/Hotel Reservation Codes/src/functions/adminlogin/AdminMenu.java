package functions.adminlogin;

import functions.customersdb.ManageCustomers;
import functions.activitiesdb.ManageActivities;
import java.util.Scanner;
import tool.SafeIntegerInput;
import users.Admin;
import functions.VerifyUser;

public class AdminMenu {

    public static void handleAdminLogin(Scanner scanner) {
        int userId = 0;
        Admin admin = (Admin) VerifyUser.verifyUser(scanner, "admin", userId);
        if (admin != null) {
            System.out.println("Logged in as Admin.");
            boolean backToMainMenu = false;
            while (!backToMainMenu) {
                System.out.println("\nAdmin Menu:");
                System.out.println("1. Register a New Customer");
                System.out.println("2. Manage Customer Reservations");
                System.out.println("3. Create a New Activity");
                System.out.println("4. Return to Main Menu");
                System.out.println("");
                System.out.print("Enter your choice: ");
                int choice = SafeIntegerInput.safeIntegerInput(scanner);

                switch (choice) {
                    case 1:
                        ManageCustomers.registerNewCustomer(scanner);
                        break;
                    case 2:
                        ManageCustomers.manageCustomerReservations(scanner);
                        break;
                    case 3:
                        ManageActivities.createNewActivity(scanner);
                        break;
                    case 4:
                        backToMainMenu = true;
                        break;
                    default:
                        System.out.println("Invalid choice, please try again.");
                }
            }
        } else {
            System.out.println("Admin ID not found or incorrect.");
        }

    }

}
