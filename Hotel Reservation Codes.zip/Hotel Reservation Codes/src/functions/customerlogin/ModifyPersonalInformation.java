package functions.customerlogin;

import java.util.Scanner;
import users.Customer;

public class ModifyPersonalInformation {

    public static void modifyPersonalInformation(Scanner scanner, Customer customer) {
        System.out.println("Modifying Personal Information for " + customer.getName());

        System.out.print("Enter new name (leave blank to keep current): ");
        scanner.nextLine(); // Clear scanner buffer
        String newName = scanner.nextLine();
        if (!newName.trim().isEmpty()) {
            customer.setName(newName);
        }

        System.out.print("Enter new contact number (leave blank to keep current): ");
        String newContactNumber = scanner.nextLine();
        if (!newContactNumber.trim().isEmpty()) {
            customer.setContactDetails(newContactNumber);
        }

        System.out.println("Personal information updated successfully.");
    }
}
