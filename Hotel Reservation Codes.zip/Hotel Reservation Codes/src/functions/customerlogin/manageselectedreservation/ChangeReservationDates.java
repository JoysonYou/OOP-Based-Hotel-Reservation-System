package functions.customerlogin.manageselectedreservation;

import hotel.Reservation;
import java.time.LocalDate;
import java.util.Scanner;
import users.Customer;
import tool.InputDate;

public class ChangeReservationDates {

    public static void changeReservationDates(Scanner scanner, Reservation reservation, Customer customer) {
        System.out.println("Current reservation dates: "
                + "Check-in: " + reservation.getCheckInDate()
                + ", Check-out: " + reservation.getCheckOutDate());

        LocalDate newCheckInDate = InputDate.inputDate(scanner, "Enter new check-in date (YYYY-MM-DD): ");
        LocalDate newCheckOutDate = InputDate.inputDate(scanner, "Enter new check-out date (YYYY-MM-DD): ");
        if (newCheckOutDate.isBefore(newCheckInDate) || newCheckOutDate.isEqual(newCheckInDate)) {
            System.out.println("Check-out date must be after check-in date.");
            changeReservationDates(scanner, reservation, customer);
        }
        customer.modifyReservation(reservation, newCheckInDate, newCheckOutDate);
        reservation.changeDates(newCheckInDate, newCheckOutDate);
        System.out.println("Reservation dates updated successfully.");
    }

}
