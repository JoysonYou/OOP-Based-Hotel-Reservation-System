package functions.customerlogin.manageselectedreservation;

import hotel.Activity;
import java.util.List;
import java.util.Scanner;
import users.Customer;
import tool.SafeIntegerInput;
import functions.activitiesdb.ManageActivities;

public class UnsubscribeFromActivity {

    public static void unsubscribeFromActivity(Scanner scanner, Customer customer) {
        System.out.println("Choose an activity to unsubscribe from:");
        List<Activity> enrolledActivities = ManageActivities.getEnrolledActivities(customer);
        if (enrolledActivities.isEmpty()) {
            System.out.println("You are not subscribed to any activities.");
            return;
        }

        for (int i = 0; i < enrolledActivities.size(); i++) {
            System.out.println((i + 1) + ". " + enrolledActivities.get(i).getName());
        }

        System.out.print("Enter your choice: ");
        int choice = SafeIntegerInput.safeIntegerInput(scanner) - 1;

        if (choice >= 0 && choice < enrolledActivities.size()) {
            Activity selectedActivity = enrolledActivities.get(choice);
            selectedActivity.removeParticipant(customer);
            System.out.println("You have been unsubscribed from " + selectedActivity.getName());
        } else {
            System.out.println("Invalid choice.");
        }
    }

}
