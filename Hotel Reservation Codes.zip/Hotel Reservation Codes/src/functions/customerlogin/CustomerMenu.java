package functions.customerlogin;

import functions.VerifyUser;
import functions.roomsdb.ManageAvailableRooms;
import java.util.Scanner;
import users.Customer;
import functions.customersdb.ManageCustomers;
import tool.SafeIntegerInput;
import users.Admin;
import users.VIPCustomer;

public class CustomerMenu {

    public static void handleCustomerLogin(Scanner scanner) {
        int userId = 0;
        Customer currentCustomer = (Customer) VerifyUser.verifyUser(scanner, "customer", userId);
        if (currentCustomer != null) {
            System.out.println("Logged in as Customer.");
            boolean backToMainMenu = false;
            while (!backToMainMenu) {
                System.out.println("\nCustomer Menu:");
                System.out.println("1. Modify Personal Information");
                System.out.println("2. Make a New Reservation");
                System.out.println("3. Manage Existing Reservations");
                System.out.println("4. Cancel an Upcoming Reservation");
                System.out.println("5. Upgrade to VIP");
                System.out.println("6. Return to Main Menu");
                System.out.println("");
                System.out.print("Enter your choice: ");
                int choice = SafeIntegerInput.safeIntegerInput(scanner);
                switch (choice) {
                    case 1:
                        ModifyPersonalInformation.modifyPersonalInformation(scanner, currentCustomer);
                        break;
                    case 2:
                        MakeNewReservation.makeNewReservation(scanner, currentCustomer, ManageAvailableRooms.getAvailableRooms()); // Assuming getAvailableRooms() method is implemented
                        break;
                    case 3:
                        ManageExistingReservations.manageExistingReservations(scanner, currentCustomer);
                        break;
                    case 4:
                        CancelReservation.cancelReservation(scanner, currentCustomer);
                        break;
                    case 5:
                        ManageCustomers.upgradeCustomerToVIP(currentCustomer.getId());

                        break;
                    case 6:
                        backToMainMenu = true;
                        break;
                    default:
                        System.out.println("Invalid choice, please try again.");
                }
            }
        } else {
            System.out.println("Customer ID not found or incorrect.");
        }
    }
}
