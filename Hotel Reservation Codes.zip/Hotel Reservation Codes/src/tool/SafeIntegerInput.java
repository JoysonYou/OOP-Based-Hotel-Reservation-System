package tool;

import java.util.Scanner;

public class SafeIntegerInput {

    public static int safeIntegerInput(Scanner scanner) {
        while (!scanner.hasNextInt()) {
            System.out.println("That's not a number! Please enter a number.");
            scanner.next(); // Consume the non-integer input
        }
        return scanner.nextInt();
    }

}
