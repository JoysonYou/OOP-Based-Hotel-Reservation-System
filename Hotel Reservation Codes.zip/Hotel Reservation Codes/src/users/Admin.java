package users;

import java.util.ArrayList;
import java.util.List;

public class Admin extends User {

    private List<Customer> managedCustomers;

    // Methods for managing customer reservations
    public Admin(int id, String password, String name, String contactDetails) {
        super(id, password, name, contactDetails);
        this.managedCustomers = new ArrayList<>();
    }

    public void addCustomer(Customer customer) {
        // Logic to add a new customer
        managedCustomers.add(customer);
    }

    public String getName() {
        return name;
    }

}
