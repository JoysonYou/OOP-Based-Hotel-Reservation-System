package rooms;

public enum RoomType {
    BASIC(500), STANDARD(1000), DELUXE(3000);

    private final double price;

    RoomType(double price) {
        this.price = price;
    }

    public double getPrice() {
        return this.price;
    }
}
