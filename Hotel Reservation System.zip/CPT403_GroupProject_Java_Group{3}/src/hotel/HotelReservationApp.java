package hotel;

import functions.Login;

public class HotelReservationApp {

    public static void main(String[] args) {
        Login.run();
    }
}
