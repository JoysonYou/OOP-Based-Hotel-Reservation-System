package hotel;

import rooms.Room;
import users.Customer;
import users.VIPCustomer;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Reservation {

    private Customer customer;
    private Room room;
    private LocalDate checkInDate;
    private LocalDate checkOutDate;
    private boolean breakfastIncluded;
    private boolean dinnerIncluded;
    private static final double DISCOUNT_RATE = 0.1; // 10% discount
    private boolean discounted;
    private static final double BREAKFAST_PRICE = 10.0; // Example price
    private static final double DINNER_PRICE = 20.0; // Example price

    // Constructor for Reservation class
    public Reservation(Customer customer, Room room, LocalDate checkInDate, LocalDate checkOutDate) {
        this.customer = customer;
        this.room = room;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
        this.breakfastIncluded = false;
        this.dinnerIncluded = false;
        this.discounted = (customer.getReservationCount() + 1) % 10 == 0;// Every 10th reservation
    }

    public Room getRoom() {
        return room;
    }

    public LocalDate getCheckInDate() {
        return checkInDate;
    }

    public LocalDate getCheckOutDate() {
        return checkOutDate;
    }

    public Customer getCustomer() {
        return customer;
    }

    public boolean isBreakfastIncluded() {
        return breakfastIncluded;
    }

    public boolean isDinnerIncluded() {
        return dinnerIncluded;
    }

    public void setCheckInDate(LocalDate checkInDate) {
        this.checkInDate = checkInDate;
    }

    public void setCheckOutDate(LocalDate checkOutDate) {
        this.checkOutDate = checkOutDate;
    }

    public void setBreakfastIncluded(boolean breakfastIncluded) {
        this.breakfastIncluded = breakfastIncluded;
    }

    public void setDinnerIncluded(boolean dinnerIncluded) {
        this.dinnerIncluded = dinnerIncluded;
    }

    public void setRoom(Room room) {
        this.room = room;
    }

    // Method to set new dates for the reservation
    public void setDates(LocalDate newCheckIn, LocalDate newCheckOut) {
        this.checkInDate = newCheckIn;
        this.checkOutDate = newCheckOut;
    }

    // Method to upgrade or downgrade the room
    public void changeRoom(Room newRoom) {
        // Ensure new room is available for the dates
        if (!newRoom.isAvailable()) {
            throw new IllegalStateException("The new room is not available for the selected dates.");
        }

        this.room.setAvailable(true); // Make the old room available
        this.room = newRoom;
        this.room.setAvailable(false); // Mark the new room as booked
    }

    public double calculatePrice() {
        double basePrice = room.getPrice(); // Assume getPrice() method exists in Room
        if (discounted) {
            return basePrice * (1 - DISCOUNT_RATE);
        }
        return basePrice;
    }

    // Method to check if this reservation overlaps with another
    public boolean overlapsWith(Reservation other) {
        return !checkOutDate.isBefore(other.checkInDate) && !checkInDate.isAfter(other.checkOutDate);
    }

    // Overloaded method to check overlap with specific dates
    public boolean overlapsWith(LocalDate newCheckIn, LocalDate newCheckOut) {
        return !newCheckOut.isBefore(this.checkInDate) && !newCheckIn.isAfter(this.checkOutDate);
    }

    // Book a room
    public static Reservation bookRoom(Customer customer, Room room, LocalDate checkIn, LocalDate checkOut) {
        if (room.isAvailable()) {
            room.setAvailable(false);
            return new Reservation(customer, room, checkIn, checkOut);
        } else {
            System.out.println("Room not available");
            return null;
        }
    }

    // Method to modify the reservation dates
    public void changeDates(LocalDate newCheckIn, LocalDate newCheckOut) {
        if (newCheckOut.isBefore(newCheckIn)) {
            throw new IllegalArgumentException("Check-out date cannot be before check-in date.");
        }
        this.checkInDate = newCheckIn;
        this.checkOutDate = newCheckOut;
    }

    // Method to cancel the reservation
    public boolean cancelReservation() {
        LocalDate today = LocalDate.now();
        if (today.plusDays(1).isBefore(this.checkInDate)) {
            this.room.setAvailable(true); // Make the room available again
            return true;
        }
        return false; // Cannot cancel reservation within 1 day of check-in
    }

    // Method to calculate the total bill for the reservation
    public double calculateTotalBill() {
        long stayDuration = ChronoUnit.DAYS.between(checkInDate, checkOutDate);
        double roomCharge = stayDuration * room.getPrice();

        double breakfastCharge = breakfastIncluded ? (BREAKFAST_PRICE * stayDuration) : 0;
        double dinnerCharge = dinnerIncluded ? (DINNER_PRICE * stayDuration) : 0;

        double totalCharge = roomCharge + breakfastCharge + dinnerCharge;
        // Apply discount if applicable
        if (customer.isIsVIP() == true) {
            totalCharge *= (1 - VIPCustomer.getVIP_DISCOUNT_RATE());
        } else if (customer.getReservationCount() % 10 == 9) { // every 10th reservation
            totalCharge *= (1 - Reservation.DISCOUNT_RATE);
        }
        System.out.println("Your settlement amount is " + totalCharge);

        return totalCharge;
    }

}
