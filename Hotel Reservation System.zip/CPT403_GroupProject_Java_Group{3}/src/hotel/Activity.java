package hotel;

import users.Customer;
import users.VIPCustomer;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Activity {

    private String name;
    private LocalDate date;
    private int capacity;
    private List<Customer> participants;

    public Activity(String name, LocalDate date, int capacity) {
        this.name = name;
        this.date = date;
        this.capacity = capacity;
        this.participants = new ArrayList<>();
    }

    public LocalDate getDate() {
        return date;
    }

    public String getName() {
        return name;
    }

    public List<Customer> getParticipants() {
        return participants;
    }

    public int getCapacity() {
        return capacity;
    }

    // Methods for managing activity participation
    public boolean addParticipant(Customer customer) {
        if ((customer.isIsVIP() == false) && participants.size() >= capacity) {
            return false;

        }

        if ((customer.isIsVIP() == true) && participants.size() >= capacity) {
            removeLastNonVIP();
        }

        participants.add(customer);
        return true;
    }

    private void removeLastNonVIP() {
        for (int i = participants.size() - 1; i >= 0; i--) {
            if (participants.get(i).isIsVIP() == false) {
                participants.remove(i);
                break;
            }
        }
    }

    // Method to remove a participant from the activity
    public void removeParticipant(Customer customer) {
        if (participants.contains(customer)) {
            participants.remove(customer);
            System.out.println(customer.getName() + " has been removed from the activity: " + this.getName());
        } else {
            System.out.println(customer.getName() + " is not enrolled in the activity: " + this.getName());
        }
    }

}
