package users;

import hotel.Reservation;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Customer extends User {

    private List<Reservation> reservations;
    private boolean isVIP = false;

    // Constructor for Customer class
    public Customer(int id, String password, String name, String contactDetails) {
        super(id, password, name, contactDetails);
        this.isVIP = false;
        this.reservations = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public boolean isIsVIP() {
        return isVIP;
    }

    public void setIsVIP(boolean isVIP) {
        this.isVIP = isVIP;
    }

    public List<Reservation> getReservations() {
        return reservations;
    }

    public String getContactDetails() {
        return contactDetails;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setContactDetails(String contactDetails) {
        this.contactDetails = contactDetails;
    }

    // Count reservations
    public int getReservationCount() {
        return reservations.size();
    }

    // Book a new reservation
    public boolean bookReservation(Reservation reservation) {
        // Check for overlapping reservations before adding
        for (Reservation existingReservation : reservations) {
            if (reservation.overlapsWith(existingReservation)) {
                System.out.println("Reservation dates overlap with an existing reservation.");
                return false;
            }
        }
        reservations.add(reservation);
        return true; // Indicate successful booking
    }

    // Modify an existing reservation
    public void modifyReservation(Reservation reservation, LocalDate newCheckIn, LocalDate newCheckOut) {
        // Check for overlap with other reservations
        for (Reservation existingReservation : reservations) {
            if (existingReservation != reservation && existingReservation.overlapsWith(newCheckIn, newCheckOut)) {
                throw new IllegalStateException("Modified reservation dates overlap with another existing reservation.");
            }
        }
        reservation.setDates(newCheckIn, newCheckOut);
    }

}
