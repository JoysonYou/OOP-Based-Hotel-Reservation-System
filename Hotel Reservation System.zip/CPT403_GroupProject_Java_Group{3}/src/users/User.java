package users;

public class User {

    protected int id;
    protected String password;
    protected String name;
    protected String contactDetails;

    // Constructor with three parameters
    public User(int id, String password, String name, String contactDetails) {
        this.id = id;
        this.password = password;
        this.name = name;
        this.contactDetails = contactDetails;
    }

    public int getId() {
        return id;
    }

    public String getPassword() {
        return password;
    }

    @Override
    public String toString() {
        return "User{" + "id=" + id + ", password=" + password + ", name=" + name + ", contactDetails=" + contactDetails + '}';
    }

}
