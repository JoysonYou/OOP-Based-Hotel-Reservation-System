package users;

import hotel.Reservation;

public class VIPCustomer extends Customer {

    private static final double VIP_DISCOUNT_RATE = 0.15; // Example discount rate

    // VIP-specific methods
    public VIPCustomer(int id, String password, String name, String contactDetails) {
        super(id, password, name, contactDetails);
        // VIP-specific initialization
    }

    public static double getVIP_DISCOUNT_RATE() {
        return VIP_DISCOUNT_RATE;
    }

    // VIP-specific methods, e.g., discounts, priority in activities
    public double calculateDiscountedPrice(Reservation reservation) {
        double basePrice = reservation.getRoom().getPrice();
        return basePrice * (1 - VIP_DISCOUNT_RATE);
    }

}
