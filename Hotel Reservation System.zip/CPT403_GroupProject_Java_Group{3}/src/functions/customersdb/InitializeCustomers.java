package functions.customersdb;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import users.Customer;

public class InitializeCustomers {

    public static List<Customer> initializeCustomers() {
        List<Customer> customers = new ArrayList<>(Arrays.asList( //                new Customer(200000, "123", "haha", "hahahaha"),
                //                new Customer(200001, "123", "haha", "hahahaha"),
                //                new Customer(200002, "123", "haha", "hahahaha")
                ));
        return customers;
    }
}
