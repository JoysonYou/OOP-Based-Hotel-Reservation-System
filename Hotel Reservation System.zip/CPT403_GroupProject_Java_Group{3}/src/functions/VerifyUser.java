package functions;

import java.util.Scanner;
import tool.SafeIntegerInput;
import users.User;
import functions.adminsdb.ManageAdmin;
import functions.customersdb.ManageCustomers;
import java.util.List;

public class VerifyUser {

    public static User verifyUser(Scanner scanner, String userType, int userId) {
        System.out.print("Enter your ID: ");
        userId = SafeIntegerInput.safeIntegerInput(scanner);
        System.out.print("Enter your password: ");
        String password = scanner.next();

        if ("admin".equalsIgnoreCase(userType)) {
            return validateCredentials(ManageAdmin.getAdmins(), userId, password);
        } else if ("customer".equalsIgnoreCase(userType)) {
            return validateCredentials(ManageCustomers.getCustomers(), userId, password);
        } else {
            return null;
        }
    }

    private static <T extends User> T validateCredentials(List<T> users, int userId, String password) {
        for (T user : users) {
            if (user.getId() == userId && user.getPassword().equals(password)) {
                return user;
            }
        }
        return null;
    }

}
