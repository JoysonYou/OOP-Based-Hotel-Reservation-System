package functions.adminlogin;

import functions.adminsdb.ManageAdmin;
import java.util.List;
import java.util.Random;
import users.Admin;
import users.Customer;

public class AssignCustomerToRandomAdmin {

    public static void assignCustomerToRandomAdmin(Customer customer) {
        Random random = new Random();
        int randomIndex = random.nextInt(ManageAdmin.getAdmins().size()); // Get a random index
        Admin assignedAdmin = ManageAdmin.getAdmins().get(randomIndex);

        assignedAdmin.addCustomer(customer); // Add the customer to the randomly selected admin
        System.out.println("Customer " + customer.getName() + " has been assigned to Admin " + assignedAdmin.getName());
    }

}
