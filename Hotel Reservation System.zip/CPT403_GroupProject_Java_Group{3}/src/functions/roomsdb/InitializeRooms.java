package functions.roomsdb;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import rooms.Room;
import rooms.RoomType;

public class InitializeRooms {

    public static List<Room> initializeRooms() {
        List<Room> rooms = new ArrayList<>(Arrays.asList(
                new Room(101, RoomType.BASIC),
                new Room(102, RoomType.BASIC),
                new Room(201, RoomType.STANDARD),
                new Room(202, RoomType.STANDARD),
                new Room(301, RoomType.DELUXE),
                new Room(302, RoomType.DELUXE)
        ));
        return rooms;
    }

}
