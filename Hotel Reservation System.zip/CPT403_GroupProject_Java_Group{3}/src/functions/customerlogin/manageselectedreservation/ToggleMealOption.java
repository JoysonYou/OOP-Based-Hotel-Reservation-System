package functions.customerlogin.manageselectedreservation;

import hotel.Reservation;
import java.util.Scanner;

public class ToggleMealOption {

    public static void toggleMealOption(Scanner scanner, Reservation reservation, String mealType) {
        boolean currentStatus = (mealType.equals("breakfast")) ? reservation.isBreakfastIncluded() : reservation.isDinnerIncluded();
        System.out.println("Current status of " + mealType + ": " + (currentStatus ? "Included" : "Not Included"));
        System.out.println("Do you want to " + (currentStatus ? "remove" : "add") + " " + mealType + "? (yes/no)");

        String userResponse = scanner.next();
        if (userResponse.equalsIgnoreCase("yes")) {
            if (mealType.equals("breakfast")) {
                reservation.setBreakfastIncluded(!currentStatus);
            } else if (mealType.equals("dinner")) {
                reservation.setDinnerIncluded(!currentStatus);
            }
            System.out.println(mealType + " option has been " + (currentStatus ? "removed from" : "added to") + " your reservation.");
        } else {
            System.out.println("No changes made to the " + mealType + " option.");
        }
    }

}
