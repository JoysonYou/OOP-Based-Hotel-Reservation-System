package functions.customerlogin.manageselectedreservation;

import hotel.Reservation;
import java.util.Scanner;
import rooms.Room;
import rooms.RoomType;
import functions.roomsdb.ManageAvailableRooms;

public class ChangeRoomCategory {

    public static void changeRoomCategory(Scanner scanner, Reservation reservation) {
        System.out.println("Current Room Category: " + reservation.getRoom().getType());
        System.out.println("Available Room Categories: BASIC, STANDARD, DELUXE");
        System.out.print("Enter new room category: ");
        String newCategory = scanner.next().toUpperCase();

        // Validate and find an available room of the new category
        Room newRoom = ManageAvailableRooms.findAvailableRoom(RoomType.valueOf(newCategory));
        if (newRoom != null) {
            reservation.setRoom(newRoom);
            System.out.println("Room category updated to " + newCategory);
        } else {
            System.out.println("No available rooms in the selected category.");
        }
    }

}
