package functions.customerlogin.manageselectedreservation;

import functions.activitiesdb.ManageActivities;
import hotel.Reservation;
import java.util.Scanner;
import users.Customer;
import tool.SafeIntegerInput;

public class ReservationMenu {

    public static void manageSelectedReservation(Scanner scanner, Reservation reservation, Customer customer) {
        boolean back = false;
        while (!back) {
            System.out.println("Managing Reservation: ");
            System.out.println("1. Change reservation dates");
            System.out.println("2. Add/Remove breakfast");
            System.out.println("3. Add/Remove dinner");
            System.out.println("4. Change room category");
            System.out.println("5. Book an activity");
            System.out.println("6. Cancel an activity");
            System.out.println("7. Settlement amount");
            System.out.println("8. Go back");
            System.out.println("");
            System.out.print("Enter your choice: ");
            int choice = SafeIntegerInput.safeIntegerInput(scanner);

            switch (choice) {
                case 1:
                    ChangeReservationDates.changeReservationDates(scanner, reservation, customer);
                    break;
                case 2:
                    ToggleMealOption.toggleMealOption(scanner, reservation, "breakfast");
                    break;
                case 3:
                    ToggleMealOption.toggleMealOption(scanner, reservation, "dinner");
                    break;
                case 4:
                    ChangeRoomCategory.changeRoomCategory(scanner, reservation);
                    break;
                case 5:
                    ManageActivities.bookActivityForCustomer(scanner, customer);
                    break;
                case 6:
                    UnsubscribeFromActivity.unsubscribeFromActivity(scanner, customer);
                    break;
                case 7:
                    reservation.calculateTotalBill();
                    break;
                case 8:
                    back = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

}
