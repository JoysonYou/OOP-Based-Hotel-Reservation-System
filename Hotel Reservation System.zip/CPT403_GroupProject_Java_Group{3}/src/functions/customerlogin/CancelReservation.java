package functions.customerlogin;

import hotel.Reservation;
import java.util.Scanner;
import users.Customer;
import tool.SafeIntegerInput;

public class CancelReservation {

    public static void cancelReservation(Scanner scanner, Customer customer) {
        System.out.println("Cancelling an Upcoming Reservation");

        // Display existing reservations
        for (int i = 0; i < customer.getReservations().size(); i++) {
            Reservation res = customer.getReservations().get(i);
            System.out.println((i + 1) + ". " + res);
        }

        System.out.print("Select a reservation to cancel: ");
        int choice = SafeIntegerInput.safeIntegerInput(scanner) - 1;
        Reservation selectedReservation = customer.getReservations().get(choice);

        if (selectedReservation.cancelReservation()) {
            customer.getReservations().remove(selectedReservation);
            System.out.println("Reservation cancelled successfully.");
        } else {
            System.out.println("Unable to cancel reservation.");
        }
    }

}
