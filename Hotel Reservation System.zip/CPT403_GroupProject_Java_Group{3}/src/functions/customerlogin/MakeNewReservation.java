package functions.customerlogin;

import hotel.Reservation;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;
import rooms.Room;
import users.Customer;
import tool.SafeIntegerInput;
import tool.InputDate;

public class MakeNewReservation {

    public static void makeNewReservation(Scanner scanner, Customer customer, List<Room> availableRooms) {
        System.out.println("Making a New Reservation");

        // Display available rooms
        for (int i = 0; i < availableRooms.size(); i++) {
            Room room = availableRooms.get(i);
            System.out.println((i + 1) + ". Room Number: " + room.getRoomNumber() + ", Type: " + room.getType());
        }

        System.out.print("Select room(input the order): ");
        int roomChoice = SafeIntegerInput.safeIntegerInput(scanner) - 1;
        Room selectedRoom = availableRooms.get(roomChoice);

        // Assuming you have methods to input and validate dates
        LocalDate checkInDate = InputDate.inputDate(scanner, "Enter check-in date (YYYY-MM-DD): ");
        LocalDate checkOutDate = InputDate.inputDate(scanner, "Enter check-out date (YYYY-MM-DD): ");
        if (checkOutDate.isBefore(checkInDate) || checkOutDate.isEqual(checkInDate)) {
            System.out.println("Check-out date must be after check-in date.");
            return;
        }
        Reservation newReservation = new Reservation(customer, selectedRoom, checkInDate, checkOutDate);
        if (!customer.bookReservation(newReservation)) {
            System.out.println("Try booking with alternative dates or rooms.");
            makeNewReservation(scanner, customer, availableRooms);
        } else {
            System.out.println("Reservation made successfully.");
        }
    }

}
