package functions.customerlogin;

import hotel.Reservation;
import java.util.List;
import java.util.Scanner;
import users.Customer;
import tool.SafeIntegerInput;
import functions.customerlogin.manageselectedreservation.ReservationMenu;

public class ManageExistingReservations {

    public static void manageExistingReservations(Scanner scanner, Customer customer) {
        List<Reservation> reservations = customer.getReservations();
        if (reservations.isEmpty()) {
            System.out.println("You have no existing reservations.");
            return;
        }

        System.out.println("Your Reservations:");
        for (int i = 0; i < reservations.size(); i++) {
            Reservation reservation = reservations.get(i);
            System.out.println((i + 1) + ". room number: " + reservation.getRoom().getRoomNumber()
                    + ", type: " + reservation.getRoom().getType()
                    + ", checkInDate: " + reservation.getCheckInDate()
                    + ", checkOutDate: " + reservation.getCheckOutDate()
                    + ", ifBreakfastIncluded: " + reservation.isBreakfastIncluded()
                    + ", ifDinnerIncluded: " + reservation.isDinnerIncluded()
            );
        }

        System.out.print("Select a reservation to manage (0 to go back): ");
        int choice = SafeIntegerInput.safeIntegerInput(scanner);
        if (choice == 0) {
            return;
        } else if (choice > 0 && choice <= reservations.size()) {
            Reservation selectedReservation = reservations.get(choice - 1);
            ReservationMenu.manageSelectedReservation(scanner, selectedReservation, customer);
        } else {
            System.out.println("Invalid selection. Please try again.");
        }
    }

}
