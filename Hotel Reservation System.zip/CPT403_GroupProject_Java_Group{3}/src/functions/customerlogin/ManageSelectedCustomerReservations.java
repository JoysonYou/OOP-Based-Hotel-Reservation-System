package functions.customerlogin;

import functions.customerlogin.manageselectedreservation.ReservationMenu;
import hotel.Reservation;
import java.util.List;
import java.util.Scanner;
import tool.SafeIntegerInput;
import users.Customer;

public class ManageSelectedCustomerReservations {

    public static void manageSelectedCustomerReservations(Scanner scanner, Customer selectedCustomer) {
        List<Reservation> reservations = selectedCustomer.getReservations();

        if (reservations.isEmpty()) {
            System.out.println("The customer has no reservations.");
            return;
        }

        boolean back = false;
        while (!back) {
            System.out.println("Reservations for " + selectedCustomer.getName() + ":");
            for (int i = 0; i < reservations.size(); i++) {
                System.out.println((i + 1) + ". " + reservations.get(i));
            }

            System.out.println((reservations.size() + 1) + ". Go back");
            System.out.print("Select a reservation to manage, or go back: ");
            int choice = SafeIntegerInput.safeIntegerInput(scanner);

            if (choice == reservations.size() + 1) {
                back = true;
            } else if (choice > 0 && choice <= reservations.size()) {
                Reservation selectedReservation = reservations.get(choice - 1);
                ReservationMenu.manageSelectedReservation(scanner, selectedReservation, selectedCustomer);
            } else {
                System.out.println("Invalid choice. Please try again.");
            }
        }
    }

}
