package tool;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

public class InputDate {

    public static LocalDate inputDate(Scanner scanner, String prompt) {
        LocalDate date = null;
        while (date == null) {
            System.out.print(prompt);
            String dateString = scanner.next();
            try {
                date = LocalDate.parse(dateString);
                if (date.isBefore(LocalDate.now())) {
                    System.out.println("Date cannot be in the past. Please try again.");
                    date = null;
                }
            } catch (DateTimeParseException e) {
                System.out.println("Invalid date format. Please enter the date in YYYY-MM-DD format.");
            }
        }
        return date;
    }

}
