package rooms;

public class Room {

    private int roomNumber;
    private RoomType type;
    private boolean isAvailable;

    // Constructor for Room class
    public Room(int roomNumber, RoomType type) {
        this.roomNumber = roomNumber;
        this.type = type;
        this.isAvailable = true;// By default, a room is available when created
    }

    // Getters and setters
    public boolean isAvailable() {
        return isAvailable;
    }

    public int getRoomNumber() {
        return roomNumber;
    }

    public RoomType getType() {
        return type;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    // Method to get the price of the room based on its type
    public double getPrice() {
        return type.getPrice();
    }

    // Other methods as needed
}
